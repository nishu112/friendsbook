(function () {
'use strict';
    

angular.module('MyApp', [ ])
.controller('MyController', function () {
  var x = "hello";
});

 });